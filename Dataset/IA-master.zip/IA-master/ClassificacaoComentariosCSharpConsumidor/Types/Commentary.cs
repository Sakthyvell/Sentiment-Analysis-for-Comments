﻿namespace ClassificacaoComentariosCSharpConsumidor.Types
{
    public class Commentary
    {
        public string Text { get; set; }
    }
}
